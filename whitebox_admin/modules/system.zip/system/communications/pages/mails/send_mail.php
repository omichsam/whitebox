
      <?php
include("../../../../connect.php");
  $subject=$_POST['subject'];
  $mails=$_POST['emails'];
  $message=$_POST['message'];
  
  include"mails/general.php"; 


?>