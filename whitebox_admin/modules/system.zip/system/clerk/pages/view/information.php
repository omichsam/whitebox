<?php
include "../../../../../connect.php";
include "../../../../../plugins/php_functions/security.php";
$innovation=$_POST['innovation'];

 // id
$today=time();

       //$new_status="6b7336564f3937355236464b693953304e50714a36716f365858447669562b383932635950796863436b413d";
       //$new_status=encrypt($status, $key);
$company_class="hidden";
$documenth="";
$older_ppt="";
$user_id="";
$company_id="";
$show_nbpart="not_shown";
$orignald_data="";
$orignal_data="not_shown";
$newbig_sectorshow="not_shown";
 $companyshown="not_shown";
 $new_sectorshow="not_shown";
 $solution="";
 $targeted="";
 $mycompany_id="";
     $impact="";
     $need="";
     $originality="";
      $busines_model="";
     $target="";
     $requirements="";
     $attachments="";
     $individual_check="checked";
     $company_check="";
     $ip_check="";
     $terms_check="";
      $Innovation_Id="";
     $solution="";
     $impact="";
     $need="";
     $busines_model="";
     $property_attachement="";
     $accepts_terms_1="";
    $intellectual_protection="";


     $Innovation_name="";
     $sector_id="";
     $InnovationBig4Sector="";
     $innovator_type="";

       $originality_explanation="";
     $Research_sources="";
     $accepts_terms_2="";
$research="";
     //$stage="";
     $intellectual_protection="";
      $newsector="";
  $bg4id_name="";
  $innovation_levelshow="not_shown";
  $InnovationLevel="";
  $useful_links="";
//$my_userde=encrypt($my_user,$key);
//echo base64_encode($new_status;
 $implementors="";
 $patner="";
 $fund="";
 $commun="";
 $statement="";
 $statepart="";
 $statecommn="";
 $statefund="";
 $stateimple="";
 $checked_implementers="";
$checked_funding="";
$checked_ipartners="";
$checked_others="";
$show_others="not_shown";

$sqlx="SELECT * FROM basic_informations where id='$innovation'";

    $query_runx=mysqli_query($con,$sqlx) or die($query_runx."<br/><br/>".mysqli_error($con));

    while($row=mysqli_fetch_array($query_runx)){
     $user_id=$row['user_id'];
     $Innovation_Id=$row['id'];
     $Innovation_name=$row['innovationName'];
     $sector_id=$row['sector_id'];
     $InnovationBig4Sector=$row['InnovationBig4Sector'];
     $InnovationLevel=$row['InnovationLevel'];
     $company_id=$row['company_id'];
     $innovator_type=$row['innovator_type'];
     $accepts_terms_1=$row['accepts_terms_1'];
     //echo "sector $InnovationBig4Sector";
/*
     $research=$row['research'];
     $solution=$row['solution'];
     $impact=$row['impact'];
     $need=$row['need'];
     $busines_model=$row['busines_model'];
     $target=$row['target'];
     $requirements=$row['requirements'];
     $attachments=$row['attachments'];
    $intellectual_protection=$row['intellectual_protection'];
$originality=$row['originality'];

       $originality_explanation=$row['originality_explanation'];
     $property_attachement=$row['property_attachement'];
     $Research_sources=$row['Research_sources'];
     $accepts_terms_2=$row['accepts_terms_1'];
     //$stage=$row['stage'];
     $intellectual_protection=$row['intellectual_protection'];
     $useful_links=$row['useful_links'];
*/
$get_innovation=mysqli_query($con,"SELECT * FROM additional_informations WHERE basicinformation_id='$innovation'") or die(mysqli_error($con));
$getinn=mysqli_fetch_assoc($get_innovation);
$need=$getinn['ProblemSolution'];
$busines_model=$getinn['CommercialModel'];
$target=$getinn['MarketPotential'];
$impact=$getinn['Feasibility'];
$solution=$getinn['Relevance'];
$requirements=$getinn['HowItWorks'];
$accepts_terms_2=$getinn['accepts_terms_2'];

 }

$get_user=mysqli_query($con,"SELECT * FROM users WHERE id='$user_id'") or die(mysqli_error($con));
$get=mysqli_fetch_assoc($get_user);
if($get){
$first_name=$get['first_name'];
//$user_id=$get['id'];
$last_name=$get['last_name'];
}else{

}
$orignal_data="not_shown";
$orignald_data="";
if($originality){
$orignal_data="";
$orignald_data=$originality_explanation;
$origdata=$originality;
}else{
$origdata="";
$orignal_data="not_shown";
}
 $sho_ppt="not_shown";
    $ppta="";
     $older_ppt="";
if($property_attachement){
    $sho_ppt="";
    $ppta="Yes";
    $older_ppt="protection_document.pdf";
}else{
    $sho_ppt="not_shown";
    $ppta="No";
    $older_ppt="";
}

$sqlxW="SELECT * FROM innovation_expectation where Innovation_id='$Innovation_Id'";
    $query_runxW=mysqli_query($con,$sqlxW) or die($query_runxW."<br/><br/>".mysqli_error($con));

    while($row=mysqli_fetch_array($query_runxW)){
  $petnership_implementors=$row['petnership_implementors'];
  $patnership_innovators=$row['patnership_innovators'];
   $funding=$row['funding'];
    $communities=$row['communities'];
    if($petnership_implementors){
     $implementors=$petnership_implementors; 

 $checked_implementers="checked";
    }else{
        
    }
     if($funding){
     $fund=$funding;   
$checked_funding="checked";
    }else{
        
    }
     if($communities){
     $commun=$communities;  
$checked_others="checked"; 
$show_others="";
    }else{
        
    }
     if($patnership_innovators){
     $patner=$patnership_innovators;
$checked_ipartners="checked";  
    }else{
        
    }
    
 
   if($implementors){
      $stateimple=" . ";
   }else{
       
   }
   if($fund){
      $statefund=" . ";
   }else{
       
   }
   if($commun){
      $statecommn=" . ";
   }else{
       
   }
    if($patner){
      $statepart=" . ";
   }else{
       
   }
    }
   
if($InnovationLevel){
$innovation_levelshow="";
}else{
$innovation_levelshow="not_shown";
}
 $company_name="";
 $get_bigfoursectors=mysqli_query($con,"SELECT company_name FROM company WHERE id='$company_id'") or die(mysqli_error($con));
$getbigid=mysqli_fetch_assoc($get_bigfoursectors);
if($getbigid){
 $company_name=$getbigid['company_name'];

if($company_name){
$mycompany_id=$company_name;
}else{
    $mycompany_id="";
}

}else{

}

 $company_class="hidden";
 $companyshown="not_shown";
 if($innovator_type=="Individual"){
$individual_check="checked";
$company_class="hidden";
  $company_check=""; 
   $companyshown="not_shown";    
 }else{
    $company_class="";
    $individual_check="";
   $company_check="checked"; 
    $companyshown="not_shown";
 }

if($intellectual_protection){
$ip_check="checked";
}else{
$ip_check="";
}

if($accepts_terms_1){
 $terms_check="checked";
}else{
 $terms_check="";
}

$get_sector=mysqli_query($con,"SELECT name FROM sectors WHERE id='$sector_id'") or die(mysqli_error($con));
$getid=mysqli_fetch_assoc($get_sector);

 $newsector=$getid['name'];
 $get_bigfoursectors=mysqli_query($con,"SELECT Name FROM bigfoursectors WHERE id='$InnovationBig4Sector'") or die(mysqli_error($con));
$getbigid=mysqli_fetch_assoc($get_bigfoursectors);
if($getbigid){
 $bg4id_name=$getbigid['Name'];


$newbig_sectorshow="not_shown";
if($bg4id_name){
$newbig_sectorshow="";
}else{
$newbig_sectorshow="not_shown";
}
}
$new_sectorshow="not_shown";
if($newsector){
$new_sectorshow="";
}else{
$new_sectorshow="not_shown";
}
  
if($intellectual_protection && $intellectual_protection){

if($Innovation_name &&  $sector_id && $InnovationBig4Sector && $innovator_type){

if($solution && $impact && $need){


     //$requirements=$row['requirements'];
if($busines_model && $target && $requirements){

    if($busines_model && $requirements){


    
if($property_attachement && $attachments){

if($accepts_terms_2){
    $page_now="first_page";
}else{
$page_now="sixth_page";
}

}else{
    $page_now="sixth_page";
}

}else{
    $page_now="fifth_page";
}

}else{
$page_now="fourth_page";
}



}else{
$page_now="third_page";
}
}else{
  $page_now="second_page";  
}
    
}else{
  $page_now="first_page";  
}



$havepatners="No";
$show_nbpart="not_shown";
$shownumbers="not_shown";
$howmany=0;
$sqlx="SELECT * FROM innovators_partners where Innovation_Id='$Innovation_Id'";

                                    $query_runx=mysqli_query($con,$sqlx) or die($query_runx."<br/><br/>".mysqli_error($con));

                                    while($row=mysqli_fetch_array($query_runx)){
                                        $howmany=$howmany+1;
                                    }
                                    if($howmany>0){
                                    $show_nbpart="";
                                  $havepatners="Yes";
                                  $shownumbers="";
                                    }else{
                                 $havepatners="No";
                                 $show_nbpart="not_shown";
                                 $shownumbers="not_shown";
                                    }
$show_propertyd="not_shown";
  $have_property="No";                                  
if($property_attachement){
 $have_property="Yes"; 
 $show_propertyd="";
}else{
     $have_property="No"; 
     $show_propertyd="not_shown";

}
$showdocs="not_shown";
$documenth="";
if($attachments){
$documenth="supporting_document.pdf";
$showdocs="";
}else{
$documenth="";
$showdocs="not_shown";
}

$show_links="not_shown";
if($useful_links){
    $show_links="";

}else{
    $show_links="not_shown";
}
$showredt="not_shown";
if($research){
$showredt="";
}else{
$showredt="not_shown";
}





?>


                                      <table class="table table-responsive table-striped col-md-12 table-bordered" width="100%">
                                        <thead>
                                          <tr><th>Field Name</th><th>Innovator's description<span style="float: right;" class="btn theme_bg" id="close_gf">Close</span></th></tr></thead>

                                          <tbody>
                                 <tr><td>Innovator Name </td><td id="innovation_displayer"><?php echo "$first_name $last_name"?></td></tr>
                                <tr><td>Innovation Name </td><td id="innovation_displayer"><?php echo $Innovation_name?></td></tr>
                                    <tr><td>Submitting as </td><td id="innovator_poselector"><?php echo $innovator_type?></td></tr>
                                     <tr class="company_data not_shown "><td>Company Name </td><td id="company_d"></td></tr>
                                    <tr class="company_files not_shown"><td>Company Registration no. </td><td id="company_nreg"></td></tr>
                                    <tr class="company_files not_shown"><td>KRA Pin </td><td id="kra_pinhold"></td></tr>
                                    <tr class="company_files not_shown"><td>Company Type </td><td id="company_typenh"></td></tr>
                              <tr><td>Sector </td><td id="sectord"><?php echo $newsector?></td></tr>
                            <tr><td>Big 4 Agenda Sector </td><td id="InnovationBig4Sectords"><?php echo $InnovationBig4Sector?></td></tr>
                          <tr><td>Gap Identified </td><td id="ptProblemidentified"><?php echo $need?></td></tr>
                          <tr><td>Relevance </td><td id="ptProblemSolution"><?php echo $solution?></td></tr>
                          <tr><td>Feasibility </td><td id="ptCommercialModel"><?php echo $impact?></td></tr>
                                    <!--<tr><td>My original idea?</td><td id="ptFeasibility"><?php echo $originality?></td></tr>
                          <tr><td>Why is/not my idea </td><td id="ptFeasibility"><?php echo $originality_explanation?></td></tr>-->

                                    <tr><td>Innovation Level </td><td id="innovation_led"><?php echo $InnovationLevel?></td></tr>
                          <!--<tr><td>Did you do a research</td><td id="ptHowItWorks"><?php echo $research?></td></tr>
                          <tr><td>Why/how did you do the research</td><td id="interlectualfr"><?php echo $Research_sources?></td></tr>-->
                          <tr><td>Market Potential</td><td id="InnovationWebsitedf"><?php echo $target?></td></tr>
                          <tr><td>Business model</td><td id="YoutubePortfolioLinksde"><?php echo $busines_model?></td></tr>
                          <tr><td>How It Works </td><td id="PastAssociationd"><?php echo $requirements?></td></tr>
                                <!--    <tr><td>Working with partners </td><td id="PastAssociationd"><?php echo $havepatners?></td></tr>
                                    
                                    <tr><td>How many are they </td><td id="PastAssociationd"><?php echo $howmany?></td></tr>
                                   <?php
                                 $coutm="";
                                  $sqlx="SELECT * FROM innovators_partners where Innovation_Id='$Innovation_Id'";

                                    $query_runx=mysqli_query($con,$sqlx) or die($query_runx."<br/><br/>".mysqli_error($con));

                                    while($row=mysqli_fetch_array($query_runx)){
                                     $member_name=$row['member_name'];
                                     $member_role=$row['member_role'];
                                     $coutm=$coutm+1;


                                   ?>
                                     <tr><td>Member/company <?php echo $coutm?> </td><td id="PastAssociationd"><?php echo $member_name." ->>>>".$member_role?></td></tr>
                                    <?php

                                    }

                                    ?>
                                    
                                    <tr><td>Reasons for submission </td><td id="PastAssociationd"><?php echo "$stateimple$implementors$statefund$fund$statecommn$commun$statepart$patner"?></td></tr>
                                    <tr><td>Have Intellectual protection</td><td id="YoutubePortfolioLinksde"><?php echo $have_property?></td></tr>
                                    <tr class="<?php echo $show_propertyd?>"><td>Intellectual protection document</td><td id="YoutubePortfolioLinksde"><i class="fa fa-file-pdf-o "></i> protection_document.pdf</td></tr>
                                    <tr class="<?php echo $showdocs?>"><td>Supporting Document </td><td id="PastAssociationd"><?php echo $documenth?></td></tr>
                          <tr class="<?php echo $show_links?>"><td>Additional link</td><td id="Affiliationsd"><?php echo $useful_links?></td></tr>-->
                                     </tbody>
                                     </table>
<script type="text/javascript">
	$(document).ready(function(){
	$("#close_gf").click(function(){
		$("#filtered_data").show();
		$("#infor_datas").hide();
	})
	})
</script>